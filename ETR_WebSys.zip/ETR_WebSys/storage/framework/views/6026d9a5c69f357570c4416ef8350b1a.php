<h1 class="text-3xl font-bold mb-4">Admin Dashboard</h1>
<p class="text-lg">Welcome, <span class="font-semibold"><?php echo e(auth()->user()->name); ?></span></p>
<p class="text-sm text-gray-600 mb-6">Email: <?php echo e(auth()->user()->email); ?></p>

<h2 class="text-2xl font-semibold mt-8 mb-4">Admin Controls</h2>

<a href="<?php echo e(route('admin.create')); ?>" class="inline-block bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition mb-6">Create Supply</a>
<a href="<?php echo e(route('register')); ?>" class="inline-block bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition mb-6">Register Users</a>

<div class="overflow-x-auto bg-white shadow rounded-lg">
   <table border="1" class="min-w-full table-auto border-collapse">
    <thead>
        <tr class="bg-gray-100 text-gray-700 text-left text-sm uppercase tracking-wider">
            <th class="px-6 py-3 border-b">Item</th>
            <th class="px-6 py-3 border-b">Unit</th>
            <th class="px-6 py-3 border-b">Quantity</th>
            <th class="px-6 py-3 border-b">Purchase Supplies</th>
            <th class="px-6 py-3 border-b">Received Supplies</th>
            <th class="px-6 py-3 border-b">Issued Supplies</th>
            <th class="px-6 py-3 border-b">Inventory End</th>
            <th class="px-6 py-3 border-b">Total Cost</th>
            <th class="px-6 py-3 border-b">Unit Cost</th>
            <th class="px-6 py-3 border-b">Amount</th>
        </tr>
    </thead>
    <tbody class="text-sm text-gray-800">
        <?php $__currentLoopData = $supplies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class="hover:bg-gray-50 transition">
            <td class="px-6 py-4 border-b"><?php echo e($supply->item); ?></td>
            <td class="px-6 py-4 border-b"><?php echo e($supply->unit); ?></td>
            <td class="px-6 py-4 border-b"><?php echo e($supply->quantity); ?></td>
            <td class="px-6 py-4 border-b"><?php echo e($supply->purchase_supplies); ?></td>
            <td class="px-6 py-4 border-b"><?php echo e($supply->received_supplies); ?></td>
            <td class="px-6 py-4 border-b"><?php echo e($supply->issued); ?></td>
            <td class="px-6 py-4 border-b"><?php echo e($supply->inventory_end); ?></td>
            <td class="px-6 py-4 border-b"><?php echo e(number_format($supply->quantity * $supply->unit_cost, 2)); ?></td>
            <td class="px-6 py-4 border-b"><?php echo e(number_format($supply->unit_cost, 2)); ?></td>
            <td class="px-6 py-4 border-b">
                <?php echo e(number_format($supply->unit_cost, 2)); ?>

            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

</div>

<form method="POST" action="<?php echo e(route('logout')); ?>" class="mt-6">
    <?php echo csrf_field(); ?>
    <button type="submit" class="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700 transition">Logout</button>
</form>
<?php /**PATH C:\Users\Lenovo\Documents\Laravel (WebSys 2)\Finals\loginpractice\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>
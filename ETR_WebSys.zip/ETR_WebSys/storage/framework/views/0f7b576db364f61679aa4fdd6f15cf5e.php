<h1>Office Dashboard</h1>
<p>Welcome, <?php echo e(auth()->user()->name); ?></p>
<p>Email: <?php echo e(auth()->user()->email); ?></p>

<h2>Office Controls</h2>
<ul>
    <li>My Documents</li>
    <li>Submit Reports</li>
    <li>View Schedule</li>
</ul>

<form method="POST" action="<?php echo e(route('logout')); ?>">
    <?php echo csrf_field(); ?>
    <button type="submit">Logout</button>
</form>
<?php /**PATH C:\Users\Lenovo\Documents\Laravel (WebSys 2)\Finals\loginpractice\resources\views/office/dashboard.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>
    <?php if(session('success')): ?>
        <div><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li style="color: red"><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('login')); ?>">
        <?php echo csrf_field(); ?>
        <div>
            <label for="role">Role: </label>
            <select name="role" required>
                <option value="admin">Admin</option>
                <option value="office">Office</option>
            </select>
        </div>
        <div>
            <label for="email">Email: </label>
            <input type="email" name="email" value="<?php echo e(old('email')); ?>" required>
        </div>
        <div>
            <label for="password">Password: </label>
            <input type="password" name="password" required>
        </div>
        <button type="submit">Login</button>
    </form>

</body>
</html><?php /**PATH C:\Users\Lenovo\Documents\Laravel (WebSys 2)\Finals\loginpractice\resources\views/Auth/login.blade.php ENDPATH**/ ?>